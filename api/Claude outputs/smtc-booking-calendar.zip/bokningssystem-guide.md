% Bokningssystemet på SMTC.se — så funkar det
% En snabbguide för Fredric

# Bokningssystemet på smtc.se — så funkar det

Den här guiden förklarar hur bokningskalendern på **prices.html** fungerar,
och vad du behöver göra när en ny bokningsförfrågan kommer in.

## Kort sammanfattning

En besökare väljer ett paket och ett datum på hemsidan och skickar in sina
uppgifter. Förfrågan hamnar direkt som en ny rad i ett **Google Sheet** —
det är det som fungerar som "databasen" och det enkla admin-systemet. Du
behöver alltså inte logga in någonstans särskilt: du öppnar bara samma
kalkylark du redan har tillgång till.

Så fort en förfrågan kommer in blockeras de datumen automatiskt i
kalendern på hemsidan, så att ingen annan kan boka samma rum samtidigt —
även innan du har hunnit bekräfta.

## Var hittar jag bokningarna?

Öppna Google-kalkylarket ("Bookings"). Varje ny förfrågan blir en ny rad
med följande kolumner:

| Kolumn | Innehåll |
|---|---|
| Timestamp | När förfrågan skickades in |
| **Status** | `pending`, `confirmed` eller `cancelled` — se nedan |
| Package | Vilket paket (Dygnet, Tvådygnare osv.) |
| Startdatum / Slutdatum | Incheck respektive utcheck |
| Nätter | Antal nätter |
| Namn / E-post / Telefon | Gästens kontaktuppgifter |
| Meddelande | Eventuellt meddelande från gästen |
| Pris | Paketpris |

## Får jag ett mejl när någon bokar?

Ja — så fort en förfrågan skickas in går det automatiskt ett
mejl-notis till din mejladress med gästens uppgifter och önskade datum.
Om mejlet uteblir, hör av dig så felsöker vi det.

## Hur bekräftar jag en bokning?

1. Öppna kalkylarket.
2. Hitta raden för bokningen.
3. Ändra cellen i kolumnen **Status** från `pending` till `confirmed`.

Det är allt — inget mer behöver göras i systemet. Datumen är redan
blockerade sedan förfrågan kom in, så det förblir bara bekräftat i
kalendern.

## Hur avbokar jag / släpper datumen igen?

Ändra Status till `cancelled`. Då försvinner blockeringen och datumen
blir tillgängliga för andra att boka igen.

*Tips: så länge en rad står som `pending` eller `confirmed` räknas
datumen som upptagna. Det är bara `cancelled` som frigör dem.*

## Hur går betalningen till?

Bokningssystemet hanterar bara själva förfrågan och datumen — inte
betalningen. Betalning sker precis som innan, utanför systemet:

- Faktura eller Företagsswish, innan ankomst (om inget annat avtalats)
- PayPal för utländska gäster (sök på Fredric Askerup /
  användarnamnet fredricaskerup)
- Moms 6 % ingår för privatpersoner, läggs på för företag

Du tar alltså kontakt med gästen (via mejl eller telefon, uppgifterna
finns i kalkylarket) när du bekräftar bokningen och stämmer av betalning
då — precis som du gjort tidigare.

## Sammanfattning i tre steg

1. **Ny förfrågan kommer in** → du får ett mejl, och en rad dyker upp i
   kalkylarket med Status `pending`. Datumen är redan blockerade.
2. **Du bekräftar** → ändra Status till `confirmed`, hör av dig till
   gästen för att stämma av betalning.
3. **Om det inte blir av** → ändra Status till `cancelled` så frigörs
   datumen.

Frågor eller vill du ändra något i hur kalendern fungerar (t.ex. vilka
veckodagar som går att boka, eller lägga till fler paket)? Hör av dig till
Malva.
