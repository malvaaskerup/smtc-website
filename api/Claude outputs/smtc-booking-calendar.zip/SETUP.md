# SMTC booking calendar — setup

This adds a simple booking calendar to `prices.html`, using a Google Sheet
as the "database" and simple admin system, and Resend to email Fredric
when someone books. It runs as two small serverless functions on Vercel —
no new hosting needed.

## What's in this folder

```
prices.html                 updated — booking form + calendar added
assets/css/style.css        updated — styles for the booking widget added
assets/js/booking.js        new — calendar logic + submits the form
api/book.js                 new — Vercel function: POST /api/book
api/availability.js         new — Vercel function: GET /api/availability
api/_sheets.js              new — shared Google Sheets helper
package.json                new (or merge into your existing one)
```

Copy these into your repo, keeping the same folder structure (drop them in
next to your existing `assets/`, `api/` if you have one, etc.). If you
already have a `package.json`, just add `"googleapis"` to its
`dependencies` instead of replacing the file.

## How it works

1. A visitor picks a package and a check-in date in the calendar on
   `prices.html`. The calendar greys out already-booked dates and — per
   the "Dagarna att välja på höst/vinter 2026 är onsdag till söndag" line
   already on the page — only allows check-in on Wednesday–Sunday.
2. On submit, `/api/book` double-checks the dates are still free, adds a
   row to your Google Sheet with status `pending`, and emails you via
   Resend.
3. The booking is **prebooked immediately** — those dates are blocked for
   everyone else — until you open the sheet and change that row's status
   to `confirmed` (or `cancelled` to release the dates again). That sheet
   *is* the simple admin system; no separate login needed.

## 1. Create the Google Sheet

1. Create a new Google Sheet (any Google account works, doesn't need to be
   fredricaskerup@gmail.com specifically — just one you check).
2. Rename the first tab to `Bookings`.
3. In row 1, add these headers exactly, one per column A–L:

   ```
   Timestamp | Status | Package | Startdatum | Slutdatum | Nätter | Namn | E-post | Telefon | Meddelande | Pris | ID
   ```

4. Copy the sheet's ID from its URL — the long string between `/d/` and
   `/edit`:
   `https://docs.google.com/spreadsheets/d/`**`THIS_PART`**`/edit`

## 2. Create a Google service account (so the website can write to the sheet)

1. Go to [console.cloud.google.com](https://console.cloud.google.com/),
   create a project (any name, e.g. "smtc-booking").
2. Enable the **Google Sheets API** for that project (search for it under
   "APIs & Services" → "Library").
3. Go to "APIs & Services" → "Credentials" → "Create credentials" →
   "Service account". Give it any name, no extra roles needed.
4. Open the new service account → "Keys" tab → "Add key" → "Create new
   key" → JSON. This downloads a `.json` file — keep it private, it's a
   password.
5. Copy two values out of that file:
   - `client_email` → this is `GOOGLE_SERVICE_ACCOUNT_EMAIL`
   - `private_key` → this is `GOOGLE_PRIVATE_KEY`
6. Back in your Google Sheet, click "Share" and share it with the
   `client_email` address from the JSON file, giving it **Editor** access.

## 3. Create a Resend account (for the notification email)

1. Sign up free at [resend.com](https://resend.com) — no credit card
   needed for the free tier.
2. Go to "API Keys" → create one → this is `RESEND_API_KEY`.
3. For the "from" address: to start, you can leave `BOOKING_FROM_EMAIL`
   unset and it'll send from Resend's shared test address
   (`onboarding@resend.dev`) — this works immediately but looks less
   professional. Once you're ready, add and verify your own domain (e.g.
   `smtc.se`) under "Domains" in Resend, then set `BOOKING_FROM_EMAIL` to
   something like `Bokning SMTC <bokning@smtc.se>`.

## 4. Add environment variables in Vercel

In your Vercel project → Settings → Environment Variables, add:

| Name | Value |
|---|---|
| `GOOGLE_SERVICE_ACCOUNT_EMAIL` | from the service account JSON |
| `GOOGLE_PRIVATE_KEY` | from the service account JSON — paste it as-is, including the `-----BEGIN PRIVATE KEY-----` / `-----END PRIVATE KEY-----` lines |
| `GOOGLE_SHEET_ID` | the sheet ID from step 1 |
| `RESEND_API_KEY` | from Resend |
| `NOTIFY_EMAIL` | the email address that should get booking notifications, e.g. `fredricaskerup@gmail.com` |
| `BOOKING_FROM_EMAIL` | optional, see step 3 |

Redeploy after adding these (Vercel only picks up new env vars on a fresh
deploy).

## 5. Test it

1. Open `prices.html` on your deployed site, scroll to "Boka paket".
2. Pick a package, pick a date, fill in a test name/email, submit.
3. Check: a new row appeared in the Google Sheet with status `pending`,
   and an email arrived at `NOTIFY_EMAIL`.
4. In the sheet, change that row's Status cell to `confirmed`. Reload
   prices.html — the calendar should still show those dates as blocked
   (both `pending` and `confirmed` block the calendar; only `cancelled`
   frees the dates again).

## Notes / things you may want to adjust later

- **Two rooms / families**: right now the calendar just books "a stay",
  not a specific room. If you want visitors to pick the Blue or Green room
  specifically, add a second dropdown and include it in the sheet — ask
  and this can be added.
- **Check-in weekday rule**: the calendar currently disables Monday and
  Tuesday as check-in days, based on the "onsdag till söndag" line already
  on prices.html. If that's not accurate, it's a two-line change in
  `assets/js/booking.js` (`isSelectableStart`).
- **Longer/custom stays**: the 2 000 kr/day longer-stay rate isn't wired
  into the calendar (it only offers the four fixed packages) — those
  guests can still use the contact details below the form or email
  directly.
- This intentionally has no login-protected admin page — the Google Sheet
  *is* the admin system, since Fredric already knows how to use a
  spreadsheet. If this grows and a proper admin page with a "confirm"
  button becomes worth it, that's a natural next step.
